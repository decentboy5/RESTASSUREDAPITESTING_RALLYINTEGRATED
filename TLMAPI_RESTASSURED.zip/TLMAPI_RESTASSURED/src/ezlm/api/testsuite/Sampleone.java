package ezlm.api.testsuite;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Map.Entry;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.Headers;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Sampleone {

	public static void main(String[] args) {
		
		Clocks.DeleteClock_Body();
		HashMap<String, String> headers = null;
		headers=Headers.getHeaders("Clocks");
		
	//	RestAssured.baseURI = "http://cdldvjasszap951:9080/adptlmj/api/codelists/v2/lcfs";
		
	//	RestAssured.baseURI = "http://cdldvjasszap951:9080/adptlmj/api/codelists/v2/lcf-values/16";
		
		
		RestAssured.baseURI="http://cdldvjasszap951:9080/adptlmj/api/codelists/v1/timeclockProfiles";
			
			//$expand=details&$filter=10001
		Response response;

		RequestSpecification httpRequest = RestAssured.given();
		
	/*	//
		httpRequest.queryParam("expand", "details");
		httpRequest.queryParam("filter", "10001");*/
		Set<Entry<String, String>> headersset = headers.entrySet();
		Iterator<Entry<String, String>> _headers = headersset.iterator();
		while (_headers.hasNext()) {
			Entry<String, String> data = _headers.next();
			String HeaderKey = data.getKey();
			String HeaderValue = data.getValue();
			if (HeaderKey == null)
				HeaderKey = "";
			if (HeaderValue == null)
				HeaderValue = "";
			httpRequest.header(HeaderKey, HeaderValue);
			
			
		}
		
		//$expand=details&$filter=10001
		
	
		response = httpRequest.get("http://cdldvjasszap951:9080/adptlmj/api/codelists/v1/timeclockProfiles?$expand=details&$filter=10001");
		System.out.println(response.getBody().asString());
	}
}
