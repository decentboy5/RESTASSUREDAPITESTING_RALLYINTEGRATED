package ezlm.api.testsuite.clocks;

import org.testng.annotations.Test;

import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class BhavaniTest extends APICall{
	
	@Test
	public void sampleTest() throws Throwable
	{
		// To Get Headers 
		headers=Headers.getHeaders("Bhavani");
		
		Response response=api_Getcall("http://vumbuild01.ad.esi.adp.com:8084/NSAPI_NL/adp.nl/ADPNL00000500/user-data", headers);
				
		APIResponse.verify_Content(response,"employeeNumber");
	}

}
