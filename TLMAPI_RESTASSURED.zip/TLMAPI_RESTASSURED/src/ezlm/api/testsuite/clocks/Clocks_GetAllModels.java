package ezlm.api.testsuite.clocks;

import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_GetAllModels extends APICall {

	
	@Test
	public void GetAllModels()
	{
		headers=Headers.getHeaders("Clocks");
		
		Response response=api_Getcall(Clocks.GetAllModels_Request,headers);		
		
		// validations
		APIResponse.verify_response(response, "data.options.label", "Intouch");
		APIResponse.verify_response(response, "data.options.label", "4500");
		APIResponse.verify_response(response, "data.options.label", "ADP300 Basic");
		APIResponse.verify_response(response, "data.options.label", "ADP700 Touchscreen");
	}
}
