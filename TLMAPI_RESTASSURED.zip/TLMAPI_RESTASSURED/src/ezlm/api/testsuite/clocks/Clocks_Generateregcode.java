package ezlm.api.testsuite.clocks;

import org.junit.Before;
import org.junit.Ignore;
import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.CommonMethods;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_Generateregcode extends APICall {

	@Test
	public void GenerateRegCode_ATS_300OR500() throws Throwable {

		// Get Headers from Property File
		headers = Headers.getHeaders("Clocks");

		// Get Call with URI and Headers
		Response response = api_Getcall(Clocks.GenerateRegCode_request, headers, Clocks.GenerateRegCode_Resource);

		// validations
		APIResponse.verify_response(response, "status", "succesqqs");

	}

	@Test
	public void Generateregcode_ATS_700() throws Throwable {

		headers = Headers.getHeaders("Clocks");

		Response response = api_Getcall(Clocks.GenerateRegCode_request, headers, Clocks.GenerateRegCode_Resource);

		APIResponse.verify_response(response, "status", "success");

	}

	@Test
	public void Generateregcode_Verify_Regcode_Length_validcase() throws Throwable {

		headers = Headers.getHeaders("Clocks");

		Response response = api_Getcall(Clocks.GenerateRegCode_request, headers, Clocks.GenerateRegCode_Resource);

		APIResponse.verify_response(response, "data.registrationCode", "length:8");

	}

	@Test
	public void Generateregcode_Verify_Regcode_Length_invalidcase() throws Throwable {

		// Get Headers from Property File
		headers = Headers.getHeaders("Clocks");

		// Get Call with URI and Headers
		Response response = api_Getcall(Clocks.GenerateRegCode_request, headers, Clocks.GenerateRegCode_Resource);

		// validations
		APIResponse.verify_response(response, "data", "");

	}

	@Test
	public void Generateregcode_Verify_locale() throws Throwable {

		// Get Headers from Property File
		headers = Headers.getHeaders("Clocks");

		// Get Call with URI and Headers
		Response response = api_Getcall(Clocks.GenerateRegCode_request, headers, Clocks.GenerateRegCode_Resource);

		// validations
		APIResponse.verify_response(response, "locale", "en-US");
	}

	@Test
	public void Generateregcode_Verify_ExpiredEstTimeZone() throws Throwable {

		headers = Headers.getHeaders("Clocks");

		Response response = api_Getcall(Clocks.GenerateRegCode_request, headers, Clocks.GenerateRegCode_Resource);

		String time = CommonMethods.geESTTime("MM.dd.yyyy hh:mma", 1);

		APIResponse.verify_Content(response, time);
	}

}
