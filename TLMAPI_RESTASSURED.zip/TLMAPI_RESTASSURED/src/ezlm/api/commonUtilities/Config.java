package ezlm.api.commonUtilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.junit.*;;

/**
 * Used to Configure Multiple Property files in the framework.
 * 
 *
 */
public class Config {

	private static Map<String, Properties> configs = new HashMap<String, Properties>();

	public static Logger Log = Logger.getLogger(Config.class);

	/**
	 * Loads a config into memory.
	 * 
	 * @param name
	 *            - name of config to load
	 */
	private static void loadConfig(String propertyfile) {

		Properties prop = new Properties();

		
		String configFileName=null;
		// build file path
		
		if(propertyfile.startsWith("TLM"))
		{
			configFileName = System.getProperty("user.dir") + "\\"+propertyfile + ".properties";
		}
		else
		{
			configFileName = System.getProperty("user.dir") + "\\PageObjectRepository\\WFN\\" + propertyfile + ".properties";
		}
		

		try {
			InputStream inputStream = new FileInputStream(configFileName);

			prop.load(inputStream);
			inputStream.close();
		} catch (IOException e) {
			Log.info("Config File Name :" + configFileName + "Error is :" + e.getMessage());
			Assert.fail(e.getMessage());

			return;
		}

		// put properties
		configs.put(propertyfile, prop);
	}

	/**
	 * Remove config from memory.
	 * 
	 * @param name
	 *            - the name of the file minus the extension
	 */
	public static void unLoadConfig(String name) {
		if (configs.containsKey(name)) {
			configs.remove(name);
		}
	}

	/**
	 * Get config. Will load the file if not loaded.
	 * 
	 * @param name
	 *            - name of the config to return
	 * @return - config
	 */
	public static Properties getConfig(String propertyfile) {
		
		// if not loaded then load config
		if (!configs.containsKey(propertyfile)) {
			loadConfig(propertyfile);
		}
		return configs.get(propertyfile);
	}

	/**
	 * get property from config/proprty files .
	 * 
	 * @param propertyfile
	 *            - name of the PageObjectRepository Property file to fetch
	 *            
	 * @param propertyName
	 *            - the property to return
	 * @return - the string value in the property
	 */
	public static String getProperty(String propertyfile, String propertyName) {
		return getConfig(propertyfile).getProperty(propertyName);
	}
	
	

	/**
	 * sets a property for a config in memory.
	 * 
	 * @param configName
	 *            - name of the config file for this property
	 * @param propertyName
	 *            - name of the property to set
	 * @param value
	 *            - the value to set the property to
	 */
	public static void setProperty(String configName, String propertyName, String value) {
		// set property in memory
		getConfig(configName).setProperty(propertyName, value);
	}
	/*
	 * public static void main(String[] args){
	 * 
	 * System.out.println( getProperty("Propery File Name", "Property")); }
	 */

}

