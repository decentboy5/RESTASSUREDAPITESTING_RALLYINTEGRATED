package ezlm.api.commonUtilities;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class SimpleGetTest {

	public static void main(String[] args) {		
		
		// Specify the base URL to the RESTful web service
			/*System.setProperty("https.proxyHost", "usproxy.es.oneadp.com");
			System.setProperty("https.proxyPort", "8080");*/
		
		
				RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city";
				
				// Get the RequestSpecification of the request that you want to sent
				// to the server. The server is specified by the BaseURI that we have
				// specified in the above step.
				RequestSpecification httpRequest = RestAssured.given();

				// Make a request to the server by specifying the method Type and the method URL.
				// This will return the Response from the server. Store the response in a variable.
				Response response = httpRequest.request(Method.GET, "/Hyderabad");

				// Now let us print the body of the message to see what response
				// we have recieved from the server
				String responseBody = response.getBody().asString();
				System.out.println("Response Body is =>  " + responseBody);
	}
	
	/*
	 * 
		RestAssured.baseURI = "http://mascsr.dit.oneadp.com/mascsr/wfntlm/codelists/v1";
		RequestSpecification httpRequest = RestAssured.given();

		httpRequest.header("ORGOID", "G3G4W00YPG4H048X");
		httpRequest.header("associateoid", "G3G4W00YPG4HVE97");
		httpRequest.header("ProductID", "WFNPortal");
		httpRequest.header("isisessionid", "KEIuEFGWEHZAyQij1SUfFdFp99o=");
		// httpRequest.header("culture","en-US");

		// Make a request to the server by specifying the method Type and the
		// method URL.
		// This will return the Response from the server. Store the response in
		// a variable.
		Response response = httpRequest.request(Method.GET, "/paycode");

		// Now let us print the body of the message to see what response
		// we have recieved from the server
		String responseBody = response.getBody().asString();
		System.out.println("Response Body is =>  " + responseBody);
	 * 
	 * */
}
