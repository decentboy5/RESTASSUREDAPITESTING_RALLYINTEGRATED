package ezlm.api.commonUtilities;

import java.util.ArrayList;
import java.util.HashMap;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class APIResponse extends APICall {

	/***
	 * 
	 * @param response
	 *            : Response object for the API Request
	 * @param keyORXpath
	 *            : specfic key or XPATH to check in the response
	 * @param expectedvalue
	 *            The value to check in the response for the given key or XPATH
	 * @throws Throwable
	 * 
	 */
	@SuppressWarnings("unchecked")
	public static void verify_response(Response response, String keyORXpath, String expectedvalue) {

		System.out.println(" ");
		Object responseFromServer = null;
		String objectType = null;
		try {

			boolean status = false;
			System.out.println("   ");

			JsonPath jsonPathEvaluator = response.jsonPath();
			responseFromServer = jsonPathEvaluator.get(keyORXpath);
			objectType = responseFromServer.getClass().getSimpleName();
			
			if (objectType.toLowerCase().equals("arraylist")) {
				ArrayList<String> actualvalue_List = (ArrayList<String>) responseFromServer;
				boolean flag = false;
				String actualvalue = null;

				for (int i = 0; i < actualvalue_List.size(); i++) {

					Object _objectType = null;
					_objectType = actualvalue_List.get(0);
					if (_objectType.getClass().getSimpleName().toLowerCase().equals("arraylist")) {
						ArrayList<String> actualValue_fromArrayList = (ArrayList<String>) _objectType;
						actualvalue = actualValue_fromArrayList.get(0);
						if (actualvalue.contains(expectedvalue)) {
							status = true;
							try {
								validateresponse(keyORXpath, actualvalue.toString(), expectedvalue);
							} catch (Throwable e) {

								System.out.println(e);
							}
							break;
						}

					} else {
						if (actualvalue_List.get(i).contains(expectedvalue)) {
							status = true;
							try {
								actualvalue = actualvalue_List.get(i);
								validateresponse(keyORXpath, actualvalue.toString(), expectedvalue);
							} catch (Throwable e) {

								System.out.println(e);
							}
							break;
						}
					}

				}

				if (!status) {

					try {
						validateresponse(keyORXpath, "notpresent", expectedvalue);
					} catch (Throwable e) {

						System.out.println(e);
					}

				}
			} else if (objectType.toLowerCase().equals("hashmap")) {
				HashMap<String, String> hashmap = (HashMap<String, String>) responseFromServer;
				int size = hashmap.size();
				if (size == 0) {

					responseFromServer = "";

					try {
						validateresponse(keyORXpath, responseFromServer.toString(), expectedvalue);
					} catch (Throwable e) {

						System.out.println(e);
					}
				}
			} else {
				responseFromServer = responseFromServer.toString();
				// Assert.assertEquals(responseFromServer, expectedvalue);
				try {
					validateresponse(keyORXpath, responseFromServer.toString(), expectedvalue);

				} catch (Throwable e) {

					System.out.println(e);
				}

			}

		} catch (Exception e) {
			
			if(objectType==null)
			{
				try {
					validateresponse(keyORXpath, "notpresent", expectedvalue);
				} catch (Throwable e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			System.out.println(e.getMessage());
		}
	}

	/**
	 * 
	 * This is used to verify the Content in the Server Response.
	 * 
	 * @param response
	 *            : Response object for the API Request
	 * 
	 * @param Content
	 *            : Verify the content in the response body
	 * @throws Throwable
	 */
	public static void verify_Content(Response response, String Content) throws Throwable {

		String _response = null;
		_response = response.getBody().asString();
		if (_response.toLowerCase().contains(Content.toLowerCase())) {
			verifyContentinResponse(Content, true);
		} else {
			verifyContentinResponse(Content, false);
		}

	}

	/***
	 * 
	 * @param response
	 * @param expected_StatusCode
	 */
	public static void verify_Response_StatusCode(Response response, int expected_StatusCode) {

		try {
			int actual_Statuscode = response.getStatusCode();
			Assert.assertEquals(actual_Statuscode, expected_StatusCode);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_StatusLine(Response response, String expected_StatusLine) {

		try {
			String actual_StatusLine = response.getStatusLine();
			actual_StatusLine = actual_StatusLine.trim();
			Assert.assertEquals(actual_StatusLine, expected_StatusLine);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_Header(Response response, String Expected_header_name) {

		try {
			String header_Response = response.getHeader(Expected_header_name);
			if (Expected_header_name.equals("Content-Type")) {
				Assert.assertEquals(header_Response, "application/json");
			} else if (Expected_header_name.equals("Connection")) {
				Assert.assertEquals(header_Response, "Keep-Alive");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
}
