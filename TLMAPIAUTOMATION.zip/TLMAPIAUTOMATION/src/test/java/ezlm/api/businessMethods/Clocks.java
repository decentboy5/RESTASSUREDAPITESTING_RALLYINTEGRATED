package ezlm.api.businessMethods;

import java.util.LinkedList;
import java.util.List;

import org.json.simple.JSONObject;

import ezlm.api.commonUtilities.CommonMethods;
import ezlm.api.commonUtilities.TestData;

public class Clocks extends TestData {

	public static String testDataFolderName = Clocks.class.getSimpleName();

	public static String GenerateRegCode_request = TestData.getProperty("Clocks#GenerateRegCode_request");

	public static String GenerateRegCode_Resource = TestData
			.getProperty(testDataFolderName + "#GenerateRegCode_Resource");

	public static String AddClock_Request = TestData.getProperty("Clocks#AddClock_Request");

	public static String AddClockresource = "/clockConfig.add";

	public static String GetAllDevices_Request = TestData.getProperty("Clocks#GetAllDevices_Request");
	public static String GetDeviceById_Request = TestData.getProperty("Clocks#GetDeviceById_Request");

	public static String GetAllLcfs_Request = TestData.getProperty("Clocks#GetAllLcfs_Request");
	public static String GetLcfByID_request = TestData.getProperty("Clocks#GetLcfByID_request");

	public static String GetAllModels_Request = TestData.getProperty("Clocks#GetAllModels_Request");

	public static String GetTimeClockProfile_Request = TestData.getProperty("Clocks#GetTimeClockProfile_Request");

	public static String DeleteClock_Request = TestData.getProperty("Clocks#DeleteClock_Request");

	public static String ClockName;

	public static String SerialNumber;

	@SuppressWarnings("unchecked")
	public static String AddClock_Body() {

		// Clock Name
		ClockName = "API_" + CommonMethods.getRandomString(5);

		System.out.println(ClockName);
		// serial Number
		SerialNumber = CommonMethods.getRanomNumber(8);

		JSONObject requestParams = new JSONObject();
		requestParams.put("objectId", "0");
		requestParams.put("dctId", ClockName);
		requestParams.put("baseDescription", "testats6");
		requestParams.put("dctModelOID", "10002");
		requestParams.put("relayType", "N");
		requestParams.put("isCommEnabled", "true");
		requestParams.put("rowVersion", "0");
		requestParams.put("isReplaceConfiguration", "false");
		JSONObject requestparam1 = new JSONObject();
		requestparam1.put("commChannelCode", "Wired");
		requestparam1.put("serialNumber", SerialNumber);
		requestparam1.put("strRegisExpDateTimeUTC", "08.31.2018 07:14AM");
		requestparam1.put("hasBiometricPod", "false");
		requestparam1.put("registrationCode", "Jf74RmKo");
		requestParams.put("dctRegistration", requestparam1);
		requestParams.put("archiveToNas", "N");
		requestParams.put("persistInDb", "N");
		requestParams.put("isBarCodeXfrEnabled", "false");
		requestParams.put("proximityState", "D");
		requestParams.put("migrationstate", "N");
		requestParams.put("gateOpenDuration", "0");
		requestParams.put("gatePassBkDuration", "0");
		requestParams.put("isGateAccessToAsgEmp", "false");
		requestParams.put("isGateTransEnabled", "false");
		List<Object> ss = new LinkedList<Object>();
		JSONObject s = new JSONObject();
		s.put("culture", "en-US");
		s.put("description", "testats6");
		ss.add(s);
		requestParams.put("descriptions", ss);
		System.out.println(requestParams.toJSONString());
		return requestParams.toJSONString();
	}

	public static String DeleteClock_Body() {

		List<Object> list_obj = new LinkedList<Object>();
		// list_obj.add("API_SSdbx");
		list_obj.add(Clocks.ClockName);
		System.out.println(list_obj.toString());
		return list_obj.toString();

	}

}
