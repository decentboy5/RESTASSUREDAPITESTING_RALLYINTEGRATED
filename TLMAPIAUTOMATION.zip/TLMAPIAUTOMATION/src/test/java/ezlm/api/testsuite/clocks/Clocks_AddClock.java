package ezlm.api.testsuite.clocks;

import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_AddClock extends APICall {

	@Test
	public void AddClock_Addclock() {

		System.out.println(Clocks.GenerateRegCode_Resource);

		headers = Headers.getHeaders("Clocks");

		Response response = api_PostCall(Clocks.AddClock_Request, Clocks.AddClockresource, headers,
				Clocks.AddClock_Body());

		APIResponse.verify_response(response, "status", "success");

	}
}
