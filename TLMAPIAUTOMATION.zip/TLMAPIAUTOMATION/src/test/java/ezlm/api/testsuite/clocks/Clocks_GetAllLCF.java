package ezlm.api.testsuite.clocks;

import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_GetAllLCF extends APICall{

	
	@Test
	public void TC996655_GetAllLcfs()
	{
		headers=Headers.getHeaders("Clocks");
		
		Response response=api_Getcall(Clocks.GetAllLcfs_Request,headers);
		
		APIResponse.verify_response(response, "data.details.description", "TimeZone");
	}
	
	
	
		
	
}
