
package ezlm.api.accelerators;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import ezlm.api.report.CReporter;
import ezlm.api.report.ReporterConstants;
import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class ActionEngine.
 */
public class ActionEngine {
	
	public static Logger log=Logger.getLogger(ActionEngine.class);

	/** The reporter. */
	public static CReporter reporter = null;

	/** The browser. */
	/* cloud platform */
	public String browser = null;

	/** The version. */
	public String version = null;

	/** The platform. */
	public String platform = null;

	/** The environment. */
	public String environment = null;

	/** The local base url. */
	public String localBaseUrl = null;

	/** The cloud base url. */
	public String cloudBaseUrl = null;

	/** The user name. */
	public String userName = null;

	/** The access key. */
	public String accessKey = null;

	/** The cloud implicit wait. */
	public String cloudImplicitWait = null;

	/** The cloud page load time out. */
	public String cloudPageLoadTimeOut = null;

	/** The update jira. */
	public String updateJira = null;

	/** The build number. */
	public String buildNumber = "";

	/** The job name. */
	public String jobName = "";

	/** The executed from. */
	public String executedFrom = null;

	@BeforeClass
	// @Parameters({"browser","browserVersion","environment","platformName"})
	// public void Helloooo(String browser, String browserVersion,String
	// environment,String platformName) throws IOException, InterruptedException
	public void BeforeClass() throws IOException, InterruptedException {
		String platformName = "flotform";
		String environment = "local";
		String browser = "Firefox";
		String browserVersion = "34";
		if (environment.equalsIgnoreCase("local")) {
			// setWebDriverForLocal(browser);
		}

		reporter = CReporter.getCReporter(browser, browserVersion, environment, true);

	}

	/**
	 * After test. - Close Driver & Reporter instance
	 *
	 * @throws Exception
	 *             the exception
	 */
	@AfterTest

	public void afterTest() throws Exception {

		reporter.createHtmlSummaryReport(true);

		reporter.closeSummaryReport();
	}

	/**
	 * Before method.
	 *
	 * @param method
	 *            the method
	 */
	@BeforeMethod

	public void beforeMethod(Method method) {

		log.info("-------------"+method.getName()+"  Started -------------");

		// get browser info
		// reporter = CReporter.getCReporter(deviceName, platformName, platformVersion,
		// true);
		reporter.initTestCase(this.getClass().getName().substring(0, this.getClass().getName().lastIndexOf(".")),
				method.getName(), "FIT", false);

	}

	/**
	 * After method.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	@AfterMethod

	public void afterMethod(Method method) throws IOException {
		
		log.info("-------------"+method.getName()+"  Ended -------------");
		// get browser info
		reporter.calculateTestCaseExecutionTime();
		reporter.closeDetailedReport();
		reporter.updateTestCaseStatus();
	}

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(ActionEngine.class);

	public boolean uriinfo_Attach_Toreport(String URI) {
		boolean status = true;
		reporter.SuccessReport("Request URI", URI);
		return status;
	}

	public void headerinfo_Attach_Toreport(HashMap<String, String> headers) {
		// TODO Auto-generated method stub
		String completeHeader = "";
		// this.reporter.SuccessReport("Headers :" , "");
		Set<Entry<String, String>> headersset = headers.entrySet();
		Iterator<Entry<String, String>> _headers = headersset.iterator();
		while (_headers.hasNext()) {
			Entry<String, String> data = _headers.next();
			String HeaderKey = data.getKey();
			String HeaderValue = data.getValue();
			completeHeader = completeHeader + HeaderKey + ":" + HeaderValue + "<br>";

		}
		reporter.SuccessReport("Headers", completeHeader);

	}

	public static void validateresponse(String key, String actual, String expected) throws Throwable {

		if (expected.startsWith("length:")) {
			expected = expected.substring(7);
			if (!actual.equalsIgnoreCase("0"))
				actual = String.valueOf(actual.length());
		}
		if (actual.isEmpty()) {
			reporter.SuccessReport("Validations :", "Expected Value for <b>" + key + "</b> is <b>{}</b> ");
		} else if (actual.equals("notpresent")) {
			reporter.failureReport("Validations :", "Expected Value for <b>" + key + "</b> = <b><font color=\"red\">"
					+ expected + "</font></b> is not present in the response ");
		} else if (!actual.equalsIgnoreCase(expected)) {
			reporter.failureReport("Validations :", "Expected Value for <b>" + key + "</b> in  response is : <b>"
					+ expected + "</b>   But Actual value is :<b><font color=\"red\">" + actual + "</font></b>");
		} else {
			reporter.SuccessReport("Validations :",
					"Expected Value for <b>" + key + "</b> in  response is : <b><font color=\"green\">\"" + expected
							+ "\"</b></font>  And Actual value is :<b>\"<font color=\"green\">" + actual
							+ "</font>\"</b>");
		}
	}

	public void responseStatusCode(int actual_Statuscode) throws Throwable {
		String _actual_Statuscode = String.valueOf(actual_Statuscode);
		reporter.SuccessReport("Status Code", _actual_Statuscode);
	}

	protected static void verifyContentinResponse(String content, boolean flag) throws Throwable {
		if (flag) {
			reporter.SuccessReport("Validation",
					"<b><font color=\"green\">" + content + "</font></b> is Present in the Response body");
		} else {
			reporter.failureReport("Response",
					"<b><font color=\"red\">" + content + "</font></b> is Not Present in the Response body");
		}

	}

	public void responsefromserver_Attach_toReport(Response response) {
		// TODO Auto-generated method stub
		reporter.SuccessReport("Response", response.getBody().asString());

		if (response.getStatusLine().contains("500")) {
			try {
				reporter.failureReport("Status Line", "<font color=\"red\">" + response.getStatusLine() + "</font>");
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			reporter.SuccessReport("Status Line", response.getStatusLine());
		}
		if (String.valueOf(response.getStatusCode()).contains("500")) {
			try {
				reporter.SuccessReport("Status Code",
						"<font color=\"red\">" + String.valueOf(response.getStatusCode()) + "</font>");
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			reporter.SuccessReport("Status Code", String.valueOf(response.getStatusCode()));
		}
		reporter.SuccessReport("Response Headers", response.getHeaders().asList().toString());

	}

	public void responsefromserver_exception_Attach_ToReport(String error) {

		try {
			reporter.failureReport("Exception :",
					"Exception while hitting the server is :<b><font color=\"red\">" + error + "</font></b>");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void requestBody(String requestBody) throws Throwable {
		// TODO Auto-generated method stub
		reporter.SuccessReport("Request Body", requestBody);

	}

	public String strwithtimestamp(String str) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		String strDateStamp = dateFormat.format(date);
		strDateStamp = ((strDateStamp.replace(" ", "_")).replace("/", "_")).replace(":", "_");

		return str + strDateStamp;
	}
}
