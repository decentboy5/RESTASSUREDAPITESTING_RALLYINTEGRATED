package ezlm.api.accelerators;

import org.apache.commons.lang3.RandomStringUtils;

public class Asas {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
		String a=RandomStringUtils.random(8,false,true);
		System.out.println(a);
		if(a.startsWith("0"))
		a=a.substring(1);
		System.out.println(a);
	}

}
