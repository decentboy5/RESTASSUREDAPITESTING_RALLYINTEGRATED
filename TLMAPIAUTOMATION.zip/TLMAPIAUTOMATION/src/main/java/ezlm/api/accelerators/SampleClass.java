package ezlm.api.accelerators;

public class SampleClass {

	public static void main(String[] args) {
		String jsonBody = "{\r\n" + "  \"firstName\": \"John\",\r\n" + "  \"lastName\": \"Smith\",\r\n"
				+ "  \"address\": {\r\n" + "    \"streetAddress\": \"21 2nd Street\",\r\n"
				+ "    \"city\": \"New York\",\r\n" + "    \"state\": \"NY\",\r\n" + "    \"postalCode\": 10021\r\n"
				+ "  },\r\n" + "  \"age\": 25,\r\n" + "  \"phoneNumbers\": [\r\n" + "    {\r\n"
				+ "      \"type\": \"home\",\r\n" + "      \"number\": \"212 555-1234\"\r\n" + "    },\r\n"
				+ "    {\r\n" + "      \"type\": \"fax\",\r\n" + "      \"number\": \"212 555-1234\"\r\n" + "    }\r\n"
				+ "  ]\r\n" + "}";

		jsonBody = jsonBody.replaceAll("\r\n\\s+", "");
		jsonBody = jsonBody.replaceAll(" ", "");
		jsonBody = jsonBody.substring(1);
		jsonBody = jsonBody.substring(0, jsonBody.length() - 1);
		String[] jsonBody1 = jsonBody.split(",");

		String key = "";
		String key1 = "";
		String value = null;
		int k = 0;
		int l = 0;
		boolean flag=false;
		for (int i = 0; i < jsonBody1.length; i++) {

			System.out.println(jsonBody1[i]);

			int brackets=0;
			if (jsonBody1[i].contains("{") || jsonBody1[i].contains("}")) { 
				
				brackets++;
				flag = true;
				if (k == 0) {
					//key = jsonBody1[i].split(":", 2)[0];
					value = jsonBody1[i].split(":", 2)[1];
					System.out.println(key);
					System.out.println(value);
					k++;
				}
				else
				{
				value=value+jsonBody1[i];
				}
				if(key.isEmpty()) {
				key=key+jsonBody1[i];}
				else { key=key+","+jsonBody1[i];}
				if(brackets==2)
				{
					String abc=key;
					String _key="";
					_key=abc.split(":")[0];
					
					
				}
			
			}
			else if(flag)
			{
				key=key+","+jsonBody1[i];
				continue;
				
			}
			else
			{
				key1=key1+jsonBody1[i];
			}
			if (l == 1) {

			}

		}
}}
