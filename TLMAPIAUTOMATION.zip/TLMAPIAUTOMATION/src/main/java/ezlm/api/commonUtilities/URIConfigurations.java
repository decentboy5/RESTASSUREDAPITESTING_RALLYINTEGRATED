package ezlm.api.commonUtilities;

public class URIConfigurations {

	public static String GetAllPayCodesURI="http://mascsr.dit.oneadp.com/mascsr/wfntlm/codelists/v1";
	
	public static String GenerateRegCode="http://cdldvjasszap951:9080/adptlmj/api/config/v1/generateregcode";
	
	public static String AddPayCodeURI="http://mascsr.dit.oneadp.com/mascsr/wfntlm/config/v1";
	
	public static String GetAllPayCodes_Resource="/10002";
	
	public static String GetAllPayCodeByID_Resource="/PayCode_API02435";
	
	public static String GetPayCodeByID="http://mascsr.dit.oneadp.com/mascsr/wfntlm/config/v1/paycode";

// GET http://cdldvjasszap951:9080/adptlmj/api/config/v1/generateregcode/10002 HTTP/1.1

	
}
