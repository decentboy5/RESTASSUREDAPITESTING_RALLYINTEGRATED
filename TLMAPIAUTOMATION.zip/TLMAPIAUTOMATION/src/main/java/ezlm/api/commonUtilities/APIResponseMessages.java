package ezlm.api.commonUtilities;

public class APIResponseMessages {

	public static String StatusLine_HTTP_200 = "HTTP/1.1 200";

	public static String StatusLine_HTTP_401 = "HTTP/1.1 401";

	public static String failure_status = "failure";

	public static String success_status = "success";

	public static String StatusCode_404 = "404";

	public static int StatusCode_200 = 200;

	public static int StatusCode_401 = 401;

	public static String Header_content_type = "Content-Type";

	public static String Header_Connection = "Connection";

}
